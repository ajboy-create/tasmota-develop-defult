#pragma once
#define GPIO_STATUS_W1TC_ADDRESS      0x24
