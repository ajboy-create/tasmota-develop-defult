#pragma once
#define timercallback void*
#define ets_printf(...)
