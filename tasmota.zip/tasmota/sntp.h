#pragma once
#define sntp_get_current_timestamp() SntpGetCurrentTimestamp()
#define sntp_init() SntpInit()
#define sntp_set_timezone(tz)
#define sntp_setservername(idx, name)
#define sntp_stop()

